
class Main {
    public static void main(String[] args) {
        GenerateBlock GB = new GenerateBlock();
        GB.GenBlock();
    }
}
